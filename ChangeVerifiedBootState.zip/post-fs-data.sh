#!/system/bin/sh
resetprop ro.boot.verifiedbootstate green

