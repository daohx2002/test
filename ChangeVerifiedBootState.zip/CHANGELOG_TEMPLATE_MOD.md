### v1.0.2 - 31.03.2024
* Added web interface

### v1.0.1 - 13.12.2023  
* Fixed some typos  
  
### v1.0.0 - 25.08.2023  
* Initial release  
